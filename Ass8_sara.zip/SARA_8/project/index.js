#!/usr/bin/env node

import { Command } from 'commander';
import dotenv from 'dotenv';
import { getAstronomyPictureOfTheDay } from './services/nasaService.js';
import { trackISSLocation } from './services/issService.js';
import { getUpcomingLaunches } from './services/launchService.js';
import { displayAPOD, displayISSLocation, displayLaunches } from './utils/displayUtils.js';
import chalk from 'chalk';

// Load environment variables
dotenv.config();

const program = new Command();

// Setup CLI
program
  .name('space-explorer')
  .description('A CLI tool to explore space data from various APIs')
  .version('1.0.0');

// NASA APOD Command
program
  .command('apod')
  .description('Get the NASA Astronomy Picture of the Day')
  .action(async () => {
    try {
      console.log(chalk.blue('🔭 Fetching the Astronomy Picture of the Day...'));
      const apodData = await getAstronomyPictureOfTheDay();
      displayAPOD(apodData);
    } catch (error) {
      console.error(chalk.red(`Error fetching APOD: ${error.message}`));
      if (error.response) {
        console.error(chalk.red(`Status: ${error.response.status}`));
        console.error(chalk.red(`API Message: ${JSON.stringify(error.response.data)}`));
      }
    }
  });

// ISS Location Command
program
  .command('iss')
  .description('Track the International Space Station location')
  .action(async () => {
    console.log(chalk.blue('🛰️ Starting ISS location tracker...'));
    console.log(chalk.yellow('Press Ctrl+C to stop tracking'));
    
    try {
      await trackISSLocation(displayISSLocation);
    } catch (error) {
      console.error(chalk.red(`Error tracking ISS: ${error.message}`));
    }
  });

// Upcoming Launches Command
program
  .command('launches')
  .description('Get upcoming space launches')
  .option('-s, --status <status>', 'Filter by launch status (e.g., active, success)')
  .option('-d, --days <number>', 'Number of days to look ahead', parseInt)
  .action(async (options) => {
    try {
      console.log(chalk.blue('🚀 Fetching upcoming launches...'));
      const launches = await getUpcomingLaunches(options.status, options.days);
      displayLaunches(launches);
    } catch (error) {
      console.error(chalk.red(`Error fetching launches: ${error.message}`));
      if (error.response) {
        console.error(chalk.red(`Status: ${error.response.status}`));
        console.error(chalk.red(`API Message: ${JSON.stringify(error.response.data)}`));
      }
    }
  });

// Add a default action for when no command is specified
program
  .action(() => {
    console.log(chalk.green('🌌 Welcome to the Space Explorer CLI! 🌌'));
    console.log(chalk.cyan('\nAvailable commands:'));
    console.log(chalk.white('  apod      - Get NASA\'s Astronomy Picture of the Day'));
    console.log(chalk.white('  iss       - Track the International Space Station'));
    console.log(chalk.white('  launches  - View upcoming space launches'));
    console.log(chalk.yellow('\nExample: npm start apod'));
    program.help();
  });

// Parse the adjusted arguments for npm start
const adjustedArgs = process.argv[0].endsWith('node') 
  ? process.argv 
  : ['node', 'index.js', ...process.argv.slice(2)];

program.parse(adjustedArgs);