import axios from 'axios';

/**
 * Fetches the current location of the International Space Station
 * @returns {Promise<Object>} ISS position with latitude and longitude
 * @throws {Error} If API request fails
 */
export async function getISSLocation() {
  try {
    const response = await axios.get('http://api.open-notify.org/iss-now.json');
    
    if (response.data.message !== 'success') {
      throw new Error(`API returned error: ${response.data.message}`);
    }
    
    return {
      latitude: response.data.iss_position.latitude,
      longitude: response.data.iss_position.longitude,
      timestamp: new Date(response.data.timestamp * 1000) // Convert UNIX timestamp to Date
    };
  } catch (error) {
    if (error.response) {
      throw new Error(`ISS API responded with status ${error.response.status}`);
    } else if (error.request) {
      throw new Error('Failed to get a response from ISS API. Please check your internet connection.');
    } else {
      throw new Error(`Error: ${error.message}`);
    }
  }
}

/**
 * Continuously tracks ISS location with regular polling
 * @param {Function} callback Function to call with each location update
 * @param {number} interval Polling interval in milliseconds
 * @returns {Function} Function to stop the tracking
 */
export async function trackISSLocation(callback, interval = 10000) {
  // Initial fetch
  try {
    const location = await getISSLocation();
    callback(location);
  } catch (error) {
    console.error(`Initial ISS location fetch failed: ${error.message}`);
  }
  
  // Set up polling
  const timer = setInterval(async () => {
    try {
      const location = await getISSLocation();
      callback(location);
    } catch (error) {
      console.error(`ISS location update failed: ${error.message}`);
    }
  }, interval);
  
  // Return function to stop polling
  return () => clearInterval(timer);
}