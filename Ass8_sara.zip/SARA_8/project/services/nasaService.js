import axios from 'axios';
import dotenv from 'dotenv';

dotenv.config();

/**
 * Fetches the NASA Astronomy Picture of the Day
 * @returns {Promise<Object>} APOD data including title, explanation, date, and image URL
 * @throws {Error} If API request fails
 */
export async function getAstronomyPictureOfTheDay() {
  try {
    const apiKey = process.env.NASA_API_KEY || 'DEMO_KEY';
    const response = await axios.get('https://api.nasa.gov/planetary/apod', {
      params: {
        api_key: apiKey
      }
    });
    
    return response.data;
  } catch (error) {
    // Enhance error with context
    if (error.response) {
      throw new Error(`NASA API responded with status ${error.response.status}: ${error.response.data.msg || error.message}`);
    } else if (error.request) {
      throw new Error('Failed to get a response from NASA API. Please check your internet connection.');
    } else {
      throw new Error(`Error setting up request: ${error.message}`);
    }
  }
}