import axios from 'axios';
import { calculateDateFromNow } from '../utils/dateUtils.js';

/**
 * Fetches upcoming space launches with optional filtering
 * @param {string} status Optional status filter (e.g., active, success)
 * @param {number} days Optional number of days to look ahead
 * @returns {Promise<Array>} List of upcoming launches
 * @throws {Error} If API request fails
 */
export async function getUpcomingLaunches(status, days) {
  try {
    let url = 'https://ll.thespacedevs.com/2.2.0/launch/upcoming/';
    
    // Build query parameters
    const params = {};
    
    if (status) {
      params.status = status;
    }
    
    if (days && !isNaN(days)) {
      const futureDate = calculateDateFromNow(days);
      params.net__lte = futureDate.toISOString();
    }
    
    const response = await axios.get(url, { params });
    
    return response.data.results || [];
  } catch (error) {
    if (error.response) {
      throw new Error(`Launch API responded with status ${error.response.status}: ${error.response.data.detail || error.message}`);
    } else if (error.request) {
      throw new Error('Failed to get a response from Launch API. Please check your internet connection.');
    } else {
      throw new Error(`Error setting up request: ${error.message}`);
    }
  }
}