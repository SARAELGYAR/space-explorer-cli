import { getISSLocation } from '../services/issService.js';
import axios from 'axios';

// Mock axios
jest.mock('axios');

describe('ISS Service', () => {
  test('getISSLocation returns location data successfully', async () => {
    // Mock successful response
    const mockResponse = {
      data: {
        message: 'success',
        timestamp: 1650980400,
        iss_position: {
          latitude: '45.1234',
          longitude: '-75.6789'
        }
      }
    };
    
    axios.get.mockResolvedValue(mockResponse);
    
    const result = await getISSLocation();
    
    expect(axios.get).toHaveBeenCalledWith('http://api.open-notify.org/iss-now.json');
    
    expect(result).toEqual({
      latitude: '45.1234',
      longitude: '-75.6789',
      timestamp: expect.any(Date)
    });
  });
  
  test('getISSLocation handles API errors', async () => {
    // Mock error response
    const errorResponse = {
      response: {
        status: 500
      }
    };
    
    axios.get.mockRejectedValue(errorResponse);
    
    await expect(getISSLocation()).rejects.toThrow('ISS API responded with status 500');
  });
  
  test('getISSLocation handles network errors', async () => {
    // Mock network error
    const networkError = {
      request: {},
      message: 'Network Error'
    };
    
    axios.get.mockRejectedValue(networkError);
    
    await expect(getISSLocation()).rejects.toThrow('Failed to get a response from ISS API');
  });
  
  test('getISSLocation handles API error message', async () => {
    // Mock response with error message
    const mockErrorResponse = {
      data: {
        message: 'error message'
      }
    };
    
    axios.get.mockResolvedValue(mockErrorResponse);
    
    await expect(getISSLocation()).rejects.toThrow('API returned error: error message');
  });
});