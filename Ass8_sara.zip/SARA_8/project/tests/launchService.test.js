import { getUpcomingLaunches } from '../services/launchService.js';
import axios from 'axios';
import { calculateDateFromNow } from '../utils/dateUtils.js';

// Mock axios
jest.mock('axios');

describe('Launch Service', () => {
  test('getUpcomingLaunches returns launches successfully', async () => {
    // Mock successful response
    const mockResponse = {
      data: {
        results: [
          {
            id: '1',
            name: 'Test Launch 1',
            net: '2023-05-15T14:00:00Z',
            status: { name: 'Go' },
            mission: { description: 'Test mission 1' },
            rocket: { configuration: { name: 'Test Rocket' } }
          },
          {
            id: '2',
            name: 'Test Launch 2',
            net: '2023-05-20T09:30:00Z',
            status: { name: 'On Hold' },
            mission: { description: 'Test mission 2' },
            rocket: { configuration: { name: 'Another Rocket' } }
          }
        ]
      }
    };
    
    axios.get.mockResolvedValue(mockResponse);
    
    const result = await getUpcomingLaunches();
    
    expect(axios.get).toHaveBeenCalledWith('https://ll.thespacedevs.com/2.2.0/launch/upcoming/', { params: {} });
    
    expect(result).toEqual(mockResponse.data.results);
    expect(result.length).toBe(2);
    expect(result[0].name).toBe('Test Launch 1');
  });
  
  test('getUpcomingLaunches handles status filter', async () => {
    // Mock successful response with filter
    const mockResponse = {
      data: {
        results: [
          {
            id: '1',
            name: 'Active Launch',
            status: { name: 'Go' }
          }
        ]
      }
    };
    
    axios.get.mockResolvedValue(mockResponse);
    
    await getUpcomingLaunches('active');
    
    expect(axios.get).toHaveBeenCalledWith('https://ll.thespacedevs.com/2.2.0/launch/upcoming/', { 
      params: { status: 'active' } 
    });
  });
  
  test('getUpcomingLaunches handles days filter', async () => {
    // Mock successful response with days filter
    const mockResponse = {
      data: {
        results: [
          {
            id: '1',
            name: 'Upcoming Launch',
            net: '2023-05-10T00:00:00Z'
          }
        ]
      }
    };
    
    axios.get.mockResolvedValue(mockResponse);
    
    const days = 30;
    const futureDate = calculateDateFromNow(days);
    
    await getUpcomingLaunches(null, days);
    
    expect(axios.get).toHaveBeenCalledWith('https://ll.thespacedevs.com/2.2.0/launch/upcoming/', { 
      params: { net__lte: futureDate.toISOString() } 
    });
  });
  
  test('getUpcomingLaunches handles API errors', async () => {
    // Mock error response
    const errorResponse = {
      response: {
        status: 429,
        data: { detail: 'Rate limit exceeded' }
      }
    };
    
    axios.get.mockRejectedValue(errorResponse);
    
    await expect(getUpcomingLaunches()).rejects.toThrow('Launch API responded with status 429: Rate limit exceeded');
  });
  
  test('getUpcomingLaunches handles empty results', async () => {
    // Mock empty results
    const mockResponse = {
      data: {}
    };
    
    axios.get.mockResolvedValue(mockResponse);
    
    const result = await getUpcomingLaunches();
    
    expect(result).toEqual([]);
  });
});