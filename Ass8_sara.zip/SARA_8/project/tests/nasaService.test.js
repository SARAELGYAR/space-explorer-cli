import { getAstronomyPictureOfTheDay } from '../services/nasaService.js';
import axios from 'axios';

// Mock axios
jest.mock('axios');

describe('NASA Service', () => {
  test('getAstronomyPictureOfTheDay returns APOD data successfully', async () => {
    // Mock successful response
    const mockResponse = {
      data: {
        date: '2023-04-26',
        explanation: 'This is a test explanation of an astronomical image.',
        title: 'Test Astronomy Picture',
        url: 'https://example.com/test-image.jpg',
        media_type: 'image'
      }
    };
    
    axios.get.mockResolvedValue(mockResponse);
    
    const result = await getAstronomyPictureOfTheDay();
    
    expect(axios.get).toHaveBeenCalledWith('https://api.nasa.gov/planetary/apod', {
      params: { api_key: expect.any(String) }
    });
    
    expect(result).toEqual(mockResponse.data);
    expect(result.title).toBe('Test Astronomy Picture');
    expect(result.media_type).toBe('image');
  });
  
  test('getAstronomyPictureOfTheDay handles API errors', async () => {
    // Mock error response
    const errorResponse = {
      response: {
        status: 400,
        data: { msg: 'Bad request' }
      }
    };
    
    axios.get.mockRejectedValue(errorResponse);
    
    await expect(getAstronomyPictureOfTheDay()).rejects.toThrow('NASA API responded with status 400');
  });
  
  test('getAstronomyPictureOfTheDay handles network errors', async () => {
    // Mock network error
    const networkError = {
      request: {},
      message: 'Network Error'
    };
    
    axios.get.mockRejectedValue(networkError);
    
    await expect(getAstronomyPictureOfTheDay()).rejects.toThrow('Failed to get a response from NASA API');
  });
});