# Space Explorer CLI

A Node.js command-line application that integrates with publicly available space-related APIs to provide information about astronomical pictures, the International Space Station (ISS) location, and upcoming space launches.

## Features

- **NASA Astronomy Picture of the Day**: View the current day's astronomy picture with details
- **ISS Location Tracker**: Track the real-time position of the International Space Station
- **Upcoming Launches**: Browse and filter upcoming space launches

## Installation

1. Clone the repository:
```
git clone <repository-url>
cd space-explorer
```

2. Install dependencies:
```
npm install
```

3. Create an environment variables file:
```
cp .env.example .env
```

4. Get a NASA API key from [https://api.nasa.gov/](https://api.nasa.gov/) and add it to your `.env` file:
```
NASA_API_KEY=your_api_key_here
```

## Usage

### View NASA's Astronomy Picture of the Day
```
npm start apod
```

### Track the ISS location
```
npm start iss
```
This will update the ISS location every 10 seconds. Press Ctrl+C to exit.

### View upcoming space launches
```
npm start launches
```

To filter launches by status:
```
npm start launches --status active
```

To filter launches by days from now:
```
npm start launches --days 30
```

## Project Structure

```
space-explorer/
├── index.js                 # Main entry point
├── services/                # API service modules
│   ├── nasaService.js       # NASA APOD API integration
│   ├── issService.js        # ISS location API integration
│   └── launchService.js     # Launch Library API integration
├── utils/                   # Utility functions
│   ├── displayUtils.js      # Display formatting utilities
│   └── dateUtils.js         # Date handling utilities
└── tests/                   # Test files
    ├── nasaService.test.js
    ├── issService.test.js
    └── launchService.test.js
```

## Testing

Run tests with:
```
npm test
```

## API Resources

- [NASA API (APOD)](https://api.nasa.gov/)
- [Open Notify ISS Location API](http://open-notify.org/Open-Notify-API/ISS-Location-Now/)
- [Launch Library 2 API](https://thespacedevs.com/llapi)

