/**
 * Calculates a date X days from now
 * @param {number} days Number of days to add to current date
 * @returns {Date} Future date
 */
export function calculateDateFromNow(days) {
  const date = new Date();
  date.setDate(date.getDate() + days);
  return date;
}

/**
 * Formats a date string in a user-friendly format
 * @param {string} dateString Date string to format
 * @returns {string} Formatted date
 */
export function formatDate(dateString) {
  const date = new Date(dateString);
  return date.toLocaleDateString(undefined, { 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}