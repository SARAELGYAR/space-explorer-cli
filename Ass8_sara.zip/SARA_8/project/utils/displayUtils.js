import chalk from 'chalk';

/**
 * Displays the NASA Astronomy Picture of the Day data
 * @param {Object} apodData The APOD data to display
 */
export function displayAPOD(apodData) {
  console.log('\n' + chalk.bgBlue.white.bold(' 🔭 NASA ASTRONOMY PICTURE OF THE DAY ') + '\n');
  
  console.log(chalk.yellow.bold('Date: ') + chalk.white(apodData.date));
  console.log(chalk.yellow.bold('Title: ') + chalk.white(apodData.title));
  
  // Draw a separator line
  console.log(chalk.dim('─'.repeat(process.stdout.columns || 80)));
  
  console.log(chalk.yellow.bold('Explanation:'));
  console.log(chalk.white(apodData.explanation));
  
  console.log(chalk.dim('─'.repeat(process.stdout.columns || 80)));
  
  // Display image URL or media type info
  if (apodData.media_type === 'image') {
    console.log(chalk.green.bold('Image URL: ') + chalk.blue.underline(apodData.url));
    console.log(chalk.green('(Copy and paste this URL into your browser to view the image)'));
  } else if (apodData.media_type === 'video') {
    console.log(chalk.green.bold('Video URL: ') + chalk.blue.underline(apodData.url));
    console.log(chalk.green('(Copy and paste this URL into your browser to view the video)'));
  }
  
  // Show copyright if available
  if (apodData.copyright) {
    console.log(chalk.dim('\n© ' + apodData.copyright));
  }
}

/**
 * Displays the current ISS location
 * @param {Object} location The ISS location data
 */
export function displayISSLocation(location) {
  const time = location.timestamp.toLocaleTimeString();
  const date = location.timestamp.toLocaleDateString();
  
  console.log(chalk.bgCyan.black.bold(` 🛰️ ISS LOCATION UPDATE: ${time} ${date} `));
  console.log(chalk.yellow.bold('  Latitude: ') + chalk.white(location.latitude));
  console.log(chalk.yellow.bold('  Longitude: ') + chalk.white(location.longitude));
  
  // Link to see ISS on map
  const mapUrl = `https://spotthestation.nasa.gov/tracking_map.cfm`;
  console.log(chalk.green(`  View on map: ${mapUrl}`));
  
  console.log(chalk.dim('─'.repeat(process.stdout.columns || 80)));
}

/**
 * Displays a list of upcoming launches
 * @param {Array} launches List of launch data
 */
export function displayLaunches(launches) {
  if (!launches || launches.length === 0) {
    console.log(chalk.yellow('\nNo upcoming launches found matching your criteria.'));
    return;
  }
  
  console.log('\n' + chalk.bgGreen.black.bold(' 🚀 UPCOMING SPACE LAUNCHES ') + '\n');
  console.log(chalk.white(`Found ${launches.length} upcoming launches:`));
  console.log(chalk.dim('─'.repeat(process.stdout.columns || 80)));
  
  launches.forEach((launch, index) => {
    // Format launch date
    const launchDate = new Date(launch.net);
    const formattedDate = launchDate.toLocaleString();
    
    console.log(chalk.blue.bold(`${index + 1}. ${launch.name}`));
    console.log(chalk.yellow.bold('  Launch Vehicle: ') + chalk.white(launch.vehicle?.name || launch.rocket?.configuration?.name || 'Unknown'));
    console.log(chalk.yellow.bold('  Launch Date: ') + chalk.white(formattedDate));
    console.log(chalk.yellow.bold('  Mission: ') + chalk.white(launch.mission?.description || 'No mission description available'));
    console.log(chalk.yellow.bold('  Status: ') + getStatusColor(launch.status?.name || 'Unknown')(launch.status?.name || 'Unknown'));
    
    // Add launch pad info if available
    if (launch.pad && launch.pad.name) {
      console.log(chalk.yellow.bold('  Launch Pad: ') + chalk.white(`${launch.pad.name}, ${launch.pad.location?.name || 'Unknown location'}`));
    }
    
    // Add link to more info
    if (launch.url) {
      console.log(chalk.green(`  More Info: ${launch.url}`));
    }
    
    console.log(chalk.dim('─'.repeat(process.stdout.columns || 80)));
  });
}

/**
 * Returns a chalk color function based on launch status
 * @param {string} status The launch status
 * @returns {Function} Chalk color function
 */
function getStatusColor(status) {
  const statusLower = status.toLowerCase();
  
  if (statusLower.includes('go') || statusLower.includes('success')) {
    return chalk.green;
  } else if (statusLower.includes('hold') || statusLower.includes('delay')) {
    return chalk.yellow;
  } else if (statusLower.includes('fail') || statusLower.includes('abort')) {
    return chalk.red;
  } else {
    return chalk.white;
  }
}